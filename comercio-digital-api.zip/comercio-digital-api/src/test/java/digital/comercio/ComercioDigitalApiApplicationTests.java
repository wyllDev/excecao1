package digital.comercio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComercioDigitalApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
