package digital.comercio.handlers;

import digital.comercio.domains.Erro;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class HttpMessageNotReadableHandler extends RunTimeExceptionHandler{

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<digital.comercio.models.requisicao.Erro> handleException(HttpMessageNotReadableException e) {
        return super.handleException(new RuntimeException(Erro.CONTATE_O_SUPORTE.getDescricao()));
    }

}
