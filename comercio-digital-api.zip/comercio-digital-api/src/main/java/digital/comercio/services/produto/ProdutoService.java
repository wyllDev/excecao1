package digital.comercio.services.produto;

import digital.comercio.dtos.request.produto.ProdutoRequestDTO;
import digital.comercio.exceptions.NegocioException;
import digital.comercio.models.login.Unidade;
import digital.comercio.models.produto.Produto;
import digital.comercio.repositorys.login.UsuarioUnidadeRepository;
import digital.comercio.repositorys.produto.ProdutoRepository;
import digital.comercio.services.login.LoginService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Optional;

import static digital.comercio.domains.Erro.*;

@Service
public class ProdutoService {

    private final ProdutoRepository produtoRepository;
    private final CategoriaProdutoService categoriaProdutoService;
    private final LoginService loginService;
    private final UsuarioUnidadeRepository usuarioUnidadeRepository;

    @Autowired
    public ProdutoService(ProdutoRepository produtoRepository, CategoriaProdutoService categoriaProdutoService, LoginService loginService, UsuarioUnidadeRepository usuarioUnidadeRepository) {
        this.produtoRepository = produtoRepository;
        this.categoriaProdutoService = categoriaProdutoService;
        this.loginService = loginService;
        this.usuarioUnidadeRepository = usuarioUnidadeRepository;
    }

    public ResponseEntity<?> registrarProduto(ProdutoRequestDTO produtoRequestDTO) {
        findProduto(produtoRequestDTO.getDescricao(), false);
        produtoRepository.save(converterProdutoRequest(produtoRequestDTO));
        return ResponseEntity.ok().build();
    }

    private Produto converterProdutoRequest(ProdutoRequestDTO produtoRequestDTO) {
        Produto produto = new ModelMapper().map(produtoRequestDTO, Produto.class);
        produto.setCategoriaProduto(categoriaProdutoService.findCategoria(produtoRequestDTO.getFrkCategoria(), true));
        produto.setUnidade(loginService.findUnidade(produtoRequestDTO.getFrkUnidade(), true));
        return produto;
    }


    public Produto findProduto(Long prk, boolean existente){
        return validarProduto(produtoRepository.findById(prk), existente);
    }

    public Produto findProduto(String descricao, boolean existente){
        return validarProduto(produtoRepository.findByDescricao(descricao), existente);
    }

    private Produto validarProduto(Optional<Produto> p, boolean existente) {
        if (p.isPresent() != existente) {
            throw new NegocioException(existente ? PRODUTO_NAO_ENCONTRADO : PRODUTO_JA_CADASTRADO);
        }
        return existente ? p.get() : null;
    }

    public ResponseEntity<?> getCategorias(Long frkUnidade) {
        Unidade unidade = loginService.findUnidade(frkUnidade, true);
        return ResponseEntity.ok().body(categoriaProdutoService.findByUnidade(unidade));
    }

    public ResponseEntity<?> getProdutos(Long prkUsuario,Long prkUnidade) {
        validarUsuario(prkUsuario, prkUnidade);
        return ResponseEntity.ok().body(produtoRepository.findByUnidade(prkUnidade));
    }

    private void validarUsuario(Long prkUsuario, Long prkUnidade) {
        if(!usuarioUnidadeRepository.usuarioPossuiPermissao(prkUsuario, prkUnidade)){
            throw new NegocioException(CONTATE_O_SUPORTE);
        }
    }
}
