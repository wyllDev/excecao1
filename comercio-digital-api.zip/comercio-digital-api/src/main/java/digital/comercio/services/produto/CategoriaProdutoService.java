package digital.comercio.services.produto;

import digital.comercio.dtos.request.produto.CategoriaProdutoRequestDTO;
import digital.comercio.exceptions.NegocioException;
import digital.comercio.models.login.Unidade;
import digital.comercio.models.produto.CategoriaProduto;
import digital.comercio.repositorys.produto.CategoriaProdutoRepository;
import digital.comercio.services.unidade.UnidadeService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import static digital.comercio.domains.Erro.CATEGORIA_JA_CADASTRADA;
import static digital.comercio.domains.Erro.CATEGORIA_NAO_ENCONTRADA;


@Service
public class CategoriaProdutoService {

    private final CategoriaProdutoRepository categoriaProdutoRepository;
    private final UnidadeService unidadeService;

    @Autowired
    public CategoriaProdutoService(CategoriaProdutoRepository categoriaProdutoRepository, UnidadeService unidadeService) {
        this.categoriaProdutoRepository = categoriaProdutoRepository;
        this.unidadeService = unidadeService;
    }


    public CategoriaProduto findCategoria(Long prk, boolean existente){
        return validarCategoria(categoriaProdutoRepository.findById(prk), existente);
    }

    public CategoriaProduto findCategoria(String descricao, boolean existente){
        return validarCategoria(categoriaProdutoRepository.findByDescricao(descricao), existente);
    }

    public List<CategoriaProduto> findByUnidade(Unidade unidade){
        return categoriaProdutoRepository.findByUnidade(unidade);
    }

    private CategoriaProduto validarCategoria(Optional<CategoriaProduto> c, boolean existente) {
        if (c.isPresent() != existente) {
            throw new NegocioException(existente ? CATEGORIA_NAO_ENCONTRADA : CATEGORIA_JA_CADASTRADA);
        }
        return existente ? c.get() : null;
    }

    public ResponseEntity<?> registrarCategoria(CategoriaProdutoRequestDTO categoriaProdutoRequestDTO) {
        findCategoria(categoriaProdutoRequestDTO.getDescricao(), false);
        Unidade unidade = unidadeService.findByPrk(categoriaProdutoRequestDTO.getFrkUnidade());
        CategoriaProduto categoriaProduto = new ModelMapper().map(categoriaProdutoRequestDTO, CategoriaProduto.class);
        categoriaProduto.setUnidade(unidade);
        categoriaProdutoRepository.save(categoriaProduto);
        return ResponseEntity.ok().build();
    }


}
