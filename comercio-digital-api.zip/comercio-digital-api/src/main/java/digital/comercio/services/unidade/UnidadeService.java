package digital.comercio.services.unidade;

import digital.comercio.domains.Erro;
import digital.comercio.exceptions.NegocioException;
import digital.comercio.models.login.Unidade;
import digital.comercio.repositorys.login.UnidadeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

import static digital.comercio.domains.Erro.UNIDADE_NAO_ENCONTRADA;

@Service
public class UnidadeService {

    private final UnidadeRepository unidadeRepository;

    @Autowired
    public UnidadeService(UnidadeRepository unidadeRepository) {
        this.unidadeRepository = unidadeRepository;
    }

    public Unidade findByPrk(Long prk){
        Optional<Unidade> unidade = unidadeRepository.findById(prk);
        if(unidade.isEmpty()){
            throw new NegocioException(UNIDADE_NAO_ENCONTRADA);
        }
        return unidade.get();
    }


}
