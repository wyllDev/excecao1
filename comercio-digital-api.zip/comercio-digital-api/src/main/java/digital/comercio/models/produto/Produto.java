package digital.comercio.models.produto;

import digital.comercio.models.login.Unidade;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;

import static javax.persistence.CascadeType.ALL;
import static javax.persistence.GenerationType.IDENTITY;

@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "produto", schema = "produto")
@Data
public class Produto {

    @Id
    @GeneratedValue(strategy = IDENTITY)
    private Long prk;

    @Column
    private String descricao;

    @Column
    private BigDecimal valor;

    @Column
    private String codigoBarras;

    @Column
    Integer quantidade;

    @OneToOne(cascade = ALL)
    @JoinColumn(name = "frkcategoria", referencedColumnName = "prk")
    private CategoriaProduto categoriaProduto;

    @ManyToOne(cascade= ALL)
    @JoinColumn(name="frkunidade", referencedColumnName = "prk")
    private Unidade unidade;

}
