package digital.comercio.repositorys.login;

import digital.comercio.models.login.UsuarioUnidade;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface UsuarioUnidadeRepository extends JpaRepository<UsuarioUnidade, Long> {

    @Query(value = "SELECT COUNT(1) > 0 FROM login.usuariounidade WHERE frkusuario = :prkUsuario AND frkunidade = :prkUnidade", nativeQuery = true)
    public boolean usuarioPossuiPermissao(@Param("prkUnidade") Long prkUnidade, @Param("prkUsuario") Long prkUsuario);

}
