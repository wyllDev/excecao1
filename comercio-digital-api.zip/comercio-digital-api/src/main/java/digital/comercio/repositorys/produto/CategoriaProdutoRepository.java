package digital.comercio.repositorys.produto;

import digital.comercio.models.login.Unidade;
import digital.comercio.models.produto.CategoriaProduto;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface CategoriaProdutoRepository extends JpaRepository<CategoriaProduto, Long> {
    Optional<CategoriaProduto> findByDescricao(String descricao);

    List<CategoriaProduto> findByUnidade(Unidade unidade);
}
