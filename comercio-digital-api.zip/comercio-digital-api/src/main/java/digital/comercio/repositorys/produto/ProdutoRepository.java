package digital.comercio.repositorys.produto;

import digital.comercio.dtos.response.produto.ProdutoResponseDTO;
import digital.comercio.models.produto.Produto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface ProdutoRepository extends JpaRepository<Produto, Long> {

    Optional<Produto> findByDescricao(String descricao);

    @Query(value = "SELECT new digital.comercio.dtos.response.produto.ProdutoResponseDTO(p.prk, p.descricao, p.valor, p.codigoBarras, p.quantidade, p.categoriaProduto.descricao) FROM Produto p WHERE p.unidade.prk = :frkUnidade")
    List<ProdutoResponseDTO> findByUnidade(Long frkUnidade);
}
