package digital.comercio.dtos.response.produto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@NoArgsConstructor
@AllArgsConstructor
@Data
@EqualsAndHashCode()
public class ProdutoResponseDTO {
    private Long codigo;
    private String descricao;
    private BigDecimal valor;
    private String codigoBarras;
    private Integer quantidade;
    private String categoria;
}
