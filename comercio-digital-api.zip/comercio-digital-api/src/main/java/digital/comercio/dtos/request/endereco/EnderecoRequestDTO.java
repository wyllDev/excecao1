package digital.comercio.dtos.request.endereco;

public class EnderecoRequestDTO {
}
