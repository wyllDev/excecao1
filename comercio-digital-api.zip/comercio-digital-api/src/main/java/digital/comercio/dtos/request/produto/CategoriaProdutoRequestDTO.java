package digital.comercio.dtos.request.produto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;


@NoArgsConstructor
@AllArgsConstructor
@Data
@EqualsAndHashCode()
public class CategoriaProdutoRequestDTO {
    private String descricao;
    private Long frkUnidade;
}
