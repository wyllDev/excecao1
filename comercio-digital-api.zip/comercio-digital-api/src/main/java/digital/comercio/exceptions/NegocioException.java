package digital.comercio.exceptions;


import digital.comercio.domains.Erro;

public class NegocioException extends RuntimeException {

    public NegocioException(Erro erro) {
        super(erro.toString());
    }
}
