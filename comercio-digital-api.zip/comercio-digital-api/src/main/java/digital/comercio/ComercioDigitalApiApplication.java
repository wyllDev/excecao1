package digital.comercio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;

@SpringBootApplication(scanBasePackages = "digital.comercio", exclude = {SecurityAutoConfiguration.class})
@EntityScan(basePackages = "digital.comercio.models")
public class ComercioDigitalApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComercioDigitalApiApplication.class, args);
	}

}
