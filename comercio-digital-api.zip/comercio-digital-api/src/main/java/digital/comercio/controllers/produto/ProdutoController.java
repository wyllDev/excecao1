package digital.comercio.controllers.produto;

import digital.comercio.annotations.token.ValidateToken;
import digital.comercio.dtos.request.produto.CategoriaProdutoRequestDTO;
import digital.comercio.dtos.request.produto.ProdutoRequestDTO;
import digital.comercio.services.produto.CategoriaProdutoService;
import digital.comercio.services.produto.ProdutoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping(value = "/produto")
public class ProdutoController {

    private final ProdutoService produtoService;
    private final CategoriaProdutoService categoriaProdutoService;

    @Autowired
    public ProdutoController(ProdutoService produtoService, CategoriaProdutoService categoriaProdutoService) {
        this.produtoService = produtoService;
        this.categoriaProdutoService = categoriaProdutoService;
    }

    @ValidateToken
    @PostMapping("/registrar")
    public ResponseEntity<?> registrarProduto(@RequestBody @Valid ProdutoRequestDTO produtoRequestDTO) {
        return produtoService.registrarProduto(produtoRequestDTO);
    }

    @ValidateToken
    @PostMapping("/categoria")
    public ResponseEntity<?> registrarCategoria(@RequestBody @Valid CategoriaProdutoRequestDTO categoriaProdutoRequestDTO) {
        return categoriaProdutoService.registrarCategoria(categoriaProdutoRequestDTO);
    }

    @ValidateToken
    @GetMapping("/categoria/{frkUnidade}")
    public ResponseEntity<?> getCategorias(@PathVariable Long frkUnidade) {
        return produtoService.getCategorias(frkUnidade);
    }

    @ValidateToken
    @GetMapping("/{prkUsuario}/{prkUnidade}")
    public ResponseEntity<?> getProdutos(@PathVariable Long prkUsuario, @PathVariable Long prkUnidade) {
        return produtoService.getProdutos(prkUsuario, prkUnidade);
    }


}
